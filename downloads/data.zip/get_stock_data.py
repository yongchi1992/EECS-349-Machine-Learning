# -*- coding: utf-8 -*-

import tushare

data=tushare.get_hist_data('sh',start='2010-01-01',end='2017-06-01')
data.to_csv('data.csv');